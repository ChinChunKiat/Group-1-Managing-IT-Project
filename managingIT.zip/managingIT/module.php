<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="description" content="KPI Assignment System"/>
	<meta name="keywords" content="HTML5, tags"/>
	<meta name="author" content="Albert Lee Kai Xian"/>
	<link rel="stylesheet" type="text/css" href="style/style1.css">

	<title>Index</title>

</head>

<body>
	<?php
    //initialise value 	
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "pasti_nyala_db2";
		
		//connect to database server
		$conn = @mysqli_connect($servername,$username,$password,$dbname);

		if($_SERVER["REQUEST_METHOD"] == "POST"){
			//include "include/connection.php";
			//$conn=mysqli_connect($servername,$username,$password,$dbname);
            //if(isset($_POST["UserID"]) && (!empty($_POST["UserID"]))){
                //$nameClr = $_POST["UserID"];
            //}

            if(isset($_POST["ModuleName"]) && (!empty($_POST["ModuleName"]))){
                $ModuleClr = $_POST["ModuleName"];;
            }

            if(isset($_POST["Description"]) && (!empty($_POST["Description"]))){
                $DescriptionClr = $_POST["Description"];
            }
			$CurrentDate = date("Y/m/d");
            //if(isset($_POST["CreateDate"]) && (!empty($_POST["CreateDate"]))){
                //$DateClr = $_POST["CreateDate"];
            //}
			
			//ensure the value are isset and run the functions
			if(isset($ModuleClr, $DescriptionClr,$CurrentDate)){
				$insert_1 = insert_in_module_table($ModuleClr, $DescriptionClr,$CurrentDate,$conn);
					mysqli_close($conn);
			}
		}

        function insert_in_module_table( $ModuleClr, $DescriptionClr,$CurrentDate,$conn){
			$sql="INSERT module_table(module_name,module_description,module_date)VALUES('$ModuleClr','$DescriptionClr','$CurrentDate')";
			if(mysqli_query($conn,$sql)){
				return True;
			}
			else{
				return False;
			}
		}
	?>
	
    <header>
		<h1>Module</h1>
	</header>
	
	<section>
		<form method="post" action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			<fieldset>
                <p><label for="fname">Module Name: </label>
				<input type="text" id="fname" name="ModuleName"  maxlength="50"></span></input></p>

                <p><label for="fname">Description: </label>
				<input type="text" id="fname" name="Description"  maxlength="50"></input></p>

				<!--Hidden date-->
				<input type="hidden" id="fname" name="CreateDate" value="$CurrentDate" maxlength="10"></input></p>

				<p><button type="submit" value="submit">Add Module</button></p>
			</fieldset>
		</form>
	</section>	
</body>
</html>