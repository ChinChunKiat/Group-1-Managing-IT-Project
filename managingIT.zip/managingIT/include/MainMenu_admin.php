<?php
	echo "
		<header>
			<h1>KPI Assignment System</h1>
		</header>
		
		<section>
			<table style='width:70%;margin-left:25%'>
				<tr style='height:300px'>
					<td >
						<div>
							<img src='image/red.png' alt='Albert Lee'>
							<li><a href='AddStaffForm.php'>Add Staff Profile</a></li>
							<li><a href='SearchStaffForm.php'>Manage Staff Profile</a></li>
							<li><a href='SearchStaffKPIForm.php'>Update Staff KPI</a></li>
						</div>
					</td>
					
					<td>
						<div>
							<img src='image/kpi_blue.png' alt='kpi'>
							<li><a href='addKPIForm.php'>Add KPI</a></li>
							<li><a href='manageKPIForm.php'>Manage KPI</a></li>
						</div>
					</td>
				</tr>
				<tr style='height:300px'>
					<td>
						<img src='image/report_green.png' alt='Albert Lee'>
						<li><a href='KPIReport.php'>KPI Overview</a></li>
					</td>
					
					<td>
						<img src='image/setting_orange.png' alt='Albert Lee'>
						<li><a href='Availability.php'>Availability</a></li>
					</td>
				</tr>
			</table>
		</section>"
?>