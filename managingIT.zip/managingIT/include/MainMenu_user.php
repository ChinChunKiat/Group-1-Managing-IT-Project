<?php
	//select data from staff_table
	$email = $_SESSION["email"];
	include "include/connection.php";
	$sql = "SELECT name, staff_id FROM staff_table WHERE email='$email'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	$_SESSION["staff_id"] = $row["staff_id"];

	echo"
		<header><h1>Welcome ".$row["name"]."</h1></header>
		
		<section style='margin:50px 40%'>
			<img src='image/red.png' alt='Albert Lee'>
			<li><a href='UserManageKPI.php'>Manage KPI</a></li>
			<li><a href='ResetPassword.php'>Manage Update Profile</a></li>
		</section>
	"
?>