<a href="MainMenu.php">Main Menu</a>
<a href="logout.php">Logout</a>

