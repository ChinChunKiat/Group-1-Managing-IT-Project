<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="description" content="KPI Assignment System"/>
	<meta name="keywords" content="HTML5, tags"/>
	<meta name="author" content="Albert Lee Kai Xian"/>
	<link rel="stylesheet" type="text/css" href="style/style1.css">

	<title>Index</title>

</head>

<body>
	<?php
    //initialise value 	
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "pasti_nyala_db2";
		
		//connect to database server
		$conn = @mysqli_connect($servername,$username,$password,$dbname);

		if($_SERVER["REQUEST_METHOD"] == "POST"){
            //include "include/connection.php";
            if(isset($_POST["SubModuleName"]) && (!empty($_POST["SubModuleName"]))){
                $SubmoduleClr = $_POST["SubModuleName"];
            }

            if(isset($_POST["FunctionName"]) && (!empty($_POST["FunctionName"]))){
                $FunctionClr = $_POST["FunctionName"];;
            }

            if(isset($_POST["FunctionDescription"]) && (!empty($_POST["FunctionDescription"]))){
                $DescriptionClr = $_POST["FunctionDescription"];
            }

            $CurrentDate = date("Y/m/d");

            // $sql = "SELECT * FROM module_table WHERE staff_id = '$nameClr'";
			// $result = mysqli_query($conn,$sql);
            // $num_result = mysqli_num_rows($result);
			// if($num_result >= 1){
				if(isset($SubmoduleClr, $FunctionClr, $DescriptionClr,$CurrentDate)){
                    $insert_1 = insert_in_function_table($SubmoduleClr, $FunctionClr, $DescriptionClr,$CurrentDate,$conn);
                    //mysqli_close($conn);
                }
			// }
            // else{
            //     $idErr = "Staff ID already exist!";
            // }
		}

        function insert_in_function_table($SubmoduleClr, $FunctionClr, $DescriptionClr,$CurrentDate,$conn){
			$sql="INSERT function_table(submodule_name,function_name,function_description,module_date)VALUES('$SubmoduleClr','$FunctionClr','$DescriptionClr','$CurrentDate')";
			if(mysqli_query($conn,$sql)){
				return True;
			}
			else{
				return False;
			}
		}
	?>
	
    <header>
		<h1>Function</h1>
	</header>
	
	<section>
		<form method="post" action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			<fieldset>
			<p><label for="SubModuleName">Sub-module Name: </label>
				<select name="SubModuleName" id="SubModuleName">
					<?php
						$sql = "SELECT submodule_name FROM submodule_table";
						$result = mysqli_query($conn,$sql);

						if ($result) {
							// Fetch each row as an associative array
							while ($row = mysqli_fetch_assoc($result)) {
								// Access the 'module_name' column value for each row
								$submoduleName = $row['submodule_name'];
						
								// Do something with $moduleName (e.g., print it)
								//echo $moduleName . "<br>";
								echo '<option value="' ,$submoduleName, '">',$submoduleName, '</option>';
							}
						
							// Free the result set
							mysqli_free_result($result);
						}
					?>
				</select></p>

                <p><label for="fname">Function Name: </label>
				<input type="text" id="fname" name="FunctionName"  maxlength="50"></span></input></p>

                <p><label for="fname">Function Description: </label>
				<input type="text" id="fname" name="FunctionDescription"  maxlength="50"></input></p>

                <!--Hidden date-->
				<input type="hidden" id="fname" name="CreateDate" value="$CurrentDate" maxlength="10"></input></p>

				<p><button type="submit" value="submit">Add Function</button></p>
			</fieldset>
		</form>
	</section>	
</body>
</html>