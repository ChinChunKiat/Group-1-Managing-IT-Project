<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <title>MIP Assignment1</title>
</head>

<body>
    <?php
    // $error = ""; // Initialize an empty error message
    
    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //     $username = $_POST["username"];
    //     $password = $_POST["password"];

    //     if (empty($username) || empty($password)) {
    //         $error = "Both fields are required"; // Set the error message
    //     } else {
    //         // Check user credentials and authentication here
    //         if (checkUserInDatabase($username, $password)) {
    //             $_SESSION['user_id'] = $username;
    //             header("Location: admin_dashboard.php");
    //             exit;
    //         } else {
    //             $error = "Invalid credentials"; // Set the error message
    //         }
    //     }
    // }
    ?>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg  navbar-dark " id="nav-bar">
        <a class="navbar-brand text-white" href="./index.html">Pasti Nyala</a>
        <!-- Toggle button for mobile navigation -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Navigation links -->

        <!--<div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link text-white" href="">Main Module</a>
                </li>
                <li class="nav-item text-white">
                    <a class="nav-link text-white" href=".">Sub Module</a>
                </li>
                <li class="nav-item text-white">
                    <a class="nav-link text-white" href=".">Function</a>
                </li>
            </ul>
        </div>-->
    </nav>

    <section class="vh-100">
        <div class="bg-image d-flex" style="
            background-image: url('./image/background.png');
            height: 100vh;
          ">
            <div class="container-fluid h-custom">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                        <form method="post" action="admin_dashboard.php">
                            <div class="divider d-flex align-items-center my-4">
                                <h2 class="text-center fw-bold mx-3 mb-0">Admin Login</h2>
                            </div>

                            <!-- ID input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="form3Example3" class="form-control form-control-lg"
                                    placeholder="Enter your id" />
                                <label class="form-label" for="Admin_ID">Admin ID : </label>
                            </div>

                            <!-- Password input -->
                            <div class="form-outline mb-3">
                                <input type="password" id="form3Example4" class="form-control form-control-lg"
                                    placeholder="Enter password" />
                                <label class="form-label" for="Admin_Password">Password</label>
                            </div>

                            <div class="d-flex justify-content-between align-items-center">
                                <!-- Checkbox -->
                                <div class="form-check mb-0">
                                    <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3" />
                                    <label class="form-check-label" for="form2Example3">
                                        Remember me
                                    </label>
                                </div>
                            </div>

                            <div class="register-button" id="input-3">
                                <div class="circle-3"></div>
                                <input type="submit" value="Login">

                                <!-- <a href="./admin.html">Login</a> -->
                            </div>
                        </form>
                    </div>
                    <div class="col-md-9 col-lg-6 col-xl-5">
                        <img src="image/admin_login.png" class="img-fluid" alt="Sample image">
                    </div>

                </div>
            </div>

            <!-- Display the error message -->
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
    </section>
</body>

<?php
// session_start();

// if (isset($_SESSION['user_id'])) {
//     // User is already logged in, redirect to admin dashboard
//     header("Location: admin_dashboard.php");
//     exit;
// }

// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     // Handle form submission and data validation here
//     $username = $_POST["Admin_ID"];
//     $password = $_POST["Admin_Password"];
//     function checkUserInDatabase($username, $password)
//     {
//         $servername = "localhost";
//         $db_username = "your_db_username";
//         $db_password = "your_db_password";
//         $dbname = "your_database_name";

//         // Create a database connection
//         $conn = new mysqli($servername, $db_username, $db_password, $dbname);

//         if ($conn->connect_error) {
//             die("Connection failed: " . $conn->connect_error);
//         }

//         // Query the database to check if the user exists with the given username and password
//         $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
//         $result = $conn->query($query);

//         // Check if a matching row is found
//         if ($result->num_rows > 0) {
//             // User exists in the database
//             $conn->close();
//             return true;
//         } else {
//             // User does not exist in the database
//             $conn->close();
//             return false;
//         }
//     }
//     // Check if the provided data exists in the database (You'll need to implement this part)
//     if (checkUserInDatabase($username, $password)) {
//         // Data exists in the database, set the user ID in the session
//         $_SESSION['user_id'] = $username;

//         // Redirect to the admin dashboard
//         header("Location: admin_dashboard.php");
//         exit;
//     } else {
//         echo "Authentication failed. Please check your data.";
//     }
// }
?>

</html>