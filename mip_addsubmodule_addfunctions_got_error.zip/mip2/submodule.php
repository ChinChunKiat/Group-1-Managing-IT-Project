<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="bootstrap, bootstrap4" />
	<meta name="author" content="QiChengDayo">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

	<!-- Additional CSS Files -->
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Admin Add sub module </title>
</head>

<body>
	<?php
	include "include/include_database.php";
	include "include/header.php";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {

	
		if (isset($_POST["ModuleName"]) && (!empty($_POST["ModuleName"]))) {
			$ModuleClr = $_POST["ModuleName"];
		}

		if (isset($_POST["SubModuleName"]) && (!empty($_POST["SubModuleName"]))) {
			$SubModuleClr = $_POST["SubModuleName"];
			;
		}

		if (isset($_POST["SubDescription"]) && (!empty($_POST["SubDescription"]))) {
			$DescriptionClr = $_POST["SubDescription"];
		}

		$CurrentDate = date("Y/m/d");


		if (isset($ModuleClr, $SubModuleClr, $DescriptionClr, $CurrentDate)) {
			$insert_1 = insert_in_submodule_table($ModuleClr, $SubModuleClr, $DescriptionClr, $CurrentDate, $conn);
		}

	}

	function insert_in_submodule_table($ModuleClr, $SubModuleClr, $DescriptionClr, $CurrentDate, $conn)
	{
		$sql = "INSERT submodule_table(module_name,submodule_name,submodule_description,module_date)VALUES('$ModuleClr','$SubModuleClr','$DescriptionClr','$CurrentDate')";
		if (mysqli_query($conn, $sql)) {
			return True;
		} else {
			return False;
		}
	}
	?>

	<div id="top" class="bg-image d-flex" style="
	background-image: url('./image/background.png');
	height:100vh;">
		<section class="container mt-5">
			<div class="col-lg-6">

				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<fieldset>
						<div class="form-group">
							<label for="ModuleName">Module Name:</label>
							<select class="form-control" name="ModuleName" id="cars">
								<?php
								$sql = "SELECT module_name FROM module_table";
								$result = mysqli_query($conn, $sql);

								if ($result) {
									while ($row = mysqli_fetch_assoc($result)) {
										$moduleName = $row['module_name'];
										echo '<option value="' . $moduleName . '">' . $moduleName . '</option>';
									}

									mysqli_free_result($result);
								}
								?>
							</select>
						</div>

						<div class="form-group">
							<label for="fname">Sub-Module Name:</label>
							<input type="text" class="form-control" id="fname" name="SubModuleName" maxlength="50">
						</div>

						<div class="form-group">
							<label for="fname">Sub-Module Description:</label>
							<input type="text" class="form-control" id="fname" name="SubDescription" maxlength="50">
						</div>

						<input type="hidden" name="CreateDate" value="<?php echo $CurrentDate; ?>" maxlength="10">

						<div class="register-button" id="input-3">
							<div class="circle-3"></div>
							<button type="submit" class="btn btn-primary">Add Submodule</button>
						</div>
					</fieldset>
				</form>
			</div>
			<div class="col-lg-6">
			</div>
		</section>
	</div>
</body>

</html>