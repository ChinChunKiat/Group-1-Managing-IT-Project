<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="bootstrap, bootstrap4" />
    <meta name="author" content="QiChengDayo">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/header.css">

    <title>Admin Register User</title>
    <style>
        .Err {
            color: red;
        }
    </style>
</head>

<body>
    <script>
        function toggleSideMenu() {
            var sideMenu = document.getElementById("sideMenu");
            sideMenu.style.width = sideMenu.style.width === "250px" ? "0" : "250px";
        }
    </script>
    <?php
    $pageTitle = "Pasti Nyala";
    $userIconPath = "./image/profile.png";
    ?>
    <header>
        <div class="header-container">
            <div class="logo">
                <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
            </div>
            <div class="user-icon" onclick="toggleSideMenu()">
                <a class="navbar-brand text-white" href="./admin_dashboard.php">
                    <img src="<?php echo $userIconPath; ?>" alt="User Icon">
                </a>
            </div>
        </div>
    </header>
    <?php
    include "include/include_database.php";
    $IdErr = "";
    $PasswordErr = "";
    $ConPasswordErr = "";
    $confirmMessage = "";
    $validate = false;

    if (!$conn) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // Get user input from the form
        $name = $_POST['name'];
        $staff_id = $_POST['staff_id'];
        $registerpassword = $_POST['password'];
        $conpassword = isset($_POST['conpassword']) ? $_POST['conpassword'] : '';

        $check_existing_sql = "SELECT * FROM login_table WHERE staff_id = '$staff_id'";
        $result = $conn->query($check_existing_sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $IdErr = "User ID already exists. Please choose a different one.";
                $validate = false;
            }
            if (
                (strlen($registerpassword) < 8)
                || !preg_match('/[A-Z]/', $registerpassword)
                || !preg_match('/[a-z]/', $registerpassword)
                || (!preg_match('/\d/', $registerpassword)
                )
            ) {
                $PasswordErr = "Password must be at least 8 characters long, one Uppercase letter, one lowercase letter, one digit number";
                $validate = false;
            } else if ($conpassword !== $registerpassword) {
                $conpasswordErr = "Password not same, Please input again";
                $validate = false;
            } else {
                $validate = true;
            }
            if ($validate === true) {
                $IdErr = "";
                $PasswordErr = "";
                $ConPasswordErr = "";
                // Insert the user information into Login_table
                $insert_sql = "INSERT INTO login_table (staff_id,name, password, type) VALUES ('$staff_id', '$name','$registerpassword', 'user')";
                if ($conn->query($insert_sql) === TRUE) {
                    $confirmMessage = "Record added successfully";
                    // echo "Record added successfully";
                } else {
                    echo "Error: " . $insert_sql . "<br>" . $conn->error;
                }
            }
        } else {
            echo "Error in query: " . $conn->error;
        }
    }
    $conn->close();
    ?>

    <div id="top" class="bg-image d-flex" style="
    background-image: url('./image/background.png');
    height:100vh;">
        <div class="container">
            <div class="container mt-5 col-lg-6">
                <h2>User Registration</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <!-- Employee Registration Form Fields -->
                    <div class="form-group" id="register_form">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="staff_id">ID:</label>
                        <input type="text" class="form-control" id="staff_id" name="staff_id" required>
                        <?php echo "<p class = 'Err'>" . $IdErr . "</p>" ?>
                    </div>

                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <?php echo "<p class = 'Err'>" . $PasswordErr . "</p>" ?>
                    </div>

                    <div class="form-group">
                        <label for="conpassword">Confirm Password:</label>
                        <input type="password" class="form-control" id="conpassword" name="conpassword" required>
                        <?php echo "<p class = 'Err'>" . $ConPasswordErr . "</p>" ?>
                    </div>
                    <div class="register-button" id="input-3">
                        <div class="circle-3"></div>
                        <button type="submit">Register</button>
                    </div>
                    <?php
                    echo "<p>" . $confirmMessage . "</p>" ?>
                </form>
            </div>
        </div>
        <div class="col-lg-6"></div>
    </div>

    <!-- Bootstrap JS and Popper.js (required for Bootstrap) -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>