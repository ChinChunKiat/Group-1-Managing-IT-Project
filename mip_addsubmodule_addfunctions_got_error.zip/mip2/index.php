<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link rel="stylesheet" href="css/header.css">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

    <title>MIP Assignment1</title>
</head>

<body>
    <?php
    $pageTitle = "Pasti Nyala";
    ?>
    <header>
        <div class="header-container">
            <div class="logo">
                <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
            </div>
        </div>
    </header>
    <?php
    include "include/create_database.php";
    include "include/include_database.php";

    ?>
    <!-- ***** Main Banner Area Start ***** -->
    <div id="top" class="bg-image d-flex" style="
    background-image: url('./image/background.png');
    height:150vh;">
        <div class="container-fluid" style="height: 300px;">
            <div class="row">
                <div class="col-lg-5">
                    <div class="left-content">
                        <div class="inner-content">
                            <h4>Pasti Nyala</h4>
                            <h6>THE BEST EXPERIENCE</h6>
                            <div class="main-white-button scroll-to-section">
                                <h6>Login As</h6>
                            </div>
                            <div class="register-button" id="input-3">
                                <div class="circle-3"></div>
                                <a href="./admin_login.php">Admin</a>
                            </div>
                            <div class="register-button" id="input-3">
                                <div class="circle-3"></div>
                                <a href="./user_login.php">User</a>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-6">
                    <div class="main-banner header-text h-25">
                        <div class="Modern-Slider ">

                            <!-- Item -->
                            <div class="item">
                                <div class="img-fill">
                                    <img src="image/menu2.png" alt="">
                                </div>
                            </div>
                            <!-- // Item -->

                            <!-- Item -->
                            <div class="item">
                                <div class="img-fill">
                                    <img src="image/menu.png" alt="">
                                </div>
                            </div>
                            <!-- // Item -->

                            <!-- Item -->
                            <div class="item">
                                <div class="img-fill">
                                    <img src="image/menu3.png" alt="">
                                </div>
                            </div>
                            <!-- // Item -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->

</body>
<!-- Footer -->
<footer class="bg-dark text-center text-white">
    <!-- Grid container -->
    <div class="container p-4">

        <!-- Section: Form -->
        <section class="">
            <form action="">
                <!--Grid row-->
                <div class="row d-flex justify-content-center">

                    <!--Grid column-->
                    <div class="col-md-5 col-12">
                        <!-- Email input -->
                        <div class="form-outline form-white mb-4">
                            <input type="text" id="form5Example21" class="form-control" placeholder="Your email" />
                        </div>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-auto">
                        <!-- Submit button -->
                        <button type="submit" class="btn btn-outline-light mb-4">
                            email us
                        </button>
                    </div>
                    <!--Grid column-->
                </div>
                <!--Grid row-->
            </form>
        </section>
        <!-- Section: Form -->

        <!-- Section: Text -->
        <section class="mb-4">
            <p style="color: aliceblue;">
                We designed and developed the following software: Accounting, Human Resources Information System,
                Payroll, Terminal Operation System, Point of Sales and Farm Operation System.

                We also supply hardware, CCTV, website design, videography and network solutions.
            </p>
        </section>
    </div>

    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        <h6 class="text-white "> © 2023 Pasti Nyala : <a class="text-white" target="blank"
                href="https://pastinyala.business.site/">Pasti Nyala.com</a>
        </h6>
    </div>
</footer>
<script src="js/slick.js"></script>

<!-- custom js -->
<script src="js/custom.js"></script>


</html>