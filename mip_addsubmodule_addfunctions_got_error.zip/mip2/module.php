<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="description" content="KPI Assignment System" />
	<meta name="keywords" content="HTML5, tags" />
	<meta name="author" content="Albert Lee Kai Xian" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="./css/style.css">

	<title>Index</title>

</head>


<body>
	<?php include "include/header.php"; ?>
	<?php
	include "include/include_database.php";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if (isset($_POST["ModuleName"]) && (!empty($_POST["ModuleName"]))) {
			$ModuleClr = $_POST["ModuleName"];

		}
		if (isset($_POST["Description"]) && (!empty($_POST["Description"]))) {
			$DescriptionClr = $_POST["Description"];
		}
		$CurrentDate = date("Y/m/d");
		//ensure the value are isset and run the functions
		if (isset($ModuleClr, $DescriptionClr, $CurrentDate)) {
			$insert_1 = insert_in_module_table($ModuleClr, $DescriptionClr, $CurrentDate, $conn);
			mysqli_close($conn);
		}
	}

	function insert_in_module_table($ModuleClr, $DescriptionClr, $CurrentDate, $conn)
	{
		$sql = "INSERT module_table(module_name,module_description,module_date)VALUES('$ModuleClr','$DescriptionClr','$CurrentDate')";
		if (mysqli_query($conn, $sql)) {
			return True;
		} else {
			return False;
		}
	}
	?>
	<div id="top" class="bg-image d-flex" style="
	background-image: url('./image/background.png');
	height:100vh;">
		<div class="container mt-5">
			<h1 class="mb-4">Module</h1>
			<section>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<fieldset>
						<div class="form-group">
							<label for="ModuleName">Module Name:</label>
							<input type="text" class="form-control" id="ModuleName" name="ModuleName" maxlength="50">
						</div>

						<div class="form-group">
							<label for="Description">Module Description:</label>
							<input type="text" class="form-control" id="Description" name="Description" maxlength="50">
						</div>

						<!-- Hidden date -->
						<input type="hidden" name="CreateDate" value="$CurrentDate" maxlength="10">

						<div class="register-button" id="input-3">
							<div class="circle-3"></div>
							<button type="submit">Add Module</button>
						</div>
					</fieldset>
				</form>
			</section>
		</div>
	</div>
	<!-- Add Bootstrap JS and Popper.js -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>