<!-- header.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="./css/header.css">
</head>

<body>
    <script>
        function toggleSideMenu() {
            var sideMenu = document.getElementById("sideMenu");
            sideMenu.style.width = sideMenu.style.width === "250px" ? "0" : "250px";
        }
    </script>
    <?php
    $pageTitle = "Pasti Nyala";
    $userIconPath = "./image/profile.png";
    ?>
    <header>
        <div class="header-container">
            <div class="logo">
                <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
            </div>
            <div class="user-icon" onclick="toggleSideMenu()">
                <img src="<?php echo $userIconPath; ?>" alt="User Icon">
            </div>
        </div>

        <!-- Inside the div with class="side-menu" -->
        <div class="side-menu" id="sideMenu">
            <div class="close-btn" onclick="toggleSideMenu()">&times;</div>

            <div class="user-info">
                <div class="user-icon" onclick="toggleSideMenu()">
                    <a href="./admin_dashboard.php">
                        <img src="<?php echo $userIconPath; ?>" alt="User Icon">
                    </a>
                </div>
                <div class="logout">
                    <a href="logout.php">Logout</a>
                </div>
            </div>

            <nav class="menu-navigation">
                <a href="module.php">Add Modules</a>
                <a href="submodule.php">Add Sub Modules</a>
                <a href="function.php">Add Functions</a>
                <a href="#">View Users</a>
                <a href="#">View Requests</a>
            </nav>
        </div>
    </header>
</body>

</html>