<?php
// Connect to the MySQL server
$servername = "localhost";
$username = "root";
$password = "Pa55w.rd";
$dbname = "pasti_nyala_db";

$conn = @mysqli_connect($servername,$username,$password,$dbname);

?>