<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="bootstrap, bootstrap4" />
	<meta name="author" content="QiChengDayo">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

	<!-- Additional CSS Files -->
	<link rel="stylesheet" type="text/css" href="./css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title>Admin Add Function </title>
</head>

<body>
	<?php
	include "include/header.php";
	include "include/include_database.php";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		if (isset($_POST["FunctionUserID"]) && (!empty($_POST["FunctionUserID"]))) {
			$nameClr = $_POST["FunctionUserID"];
		}

		if (isset($_POST["FunctionName"]) && (!empty($_POST["FunctionName"]))) {
			$ModuleClr = $_POST["FunctionName"];
			;
		}

		if (isset($_POST["FunctionDescription"]) && (!empty($_POST["FunctionDescription"]))) {
			$DescriptionClr = $_POST["FunctionDescription"];
		}

		if (isset($_POST["FunctionDate"]) && (!empty($_POST["FunctionDate"]))) {
			$DateClr = $_POST["FunctionDate"];
		}

		$sql = "SELECT * FROM module_table WHERE staff_id = '$nameClr'";
		$result = mysqli_query($conn, $sql);
		$num_result = mysqli_num_rows($result);
		if ($num_result >= 1) {
			if (isset($nameClr, $ModuleClr, $DescriptionClr, $DateClr)) {
				$insert_1 = insert_in_function_table($nameClr, $ModuleClr, $DescriptionClr, $DateClr, $conn);
				mysqli_close($conn);
			}
		} else {
			$idErr = "Staff ID already exist!";
		}
	}

	function insert_in_function_table($nameClr, $ModuleClr, $DescriptionClr, $DateClr, $conn)
	{
		$sql = "INSERT function_table(staff_id,function_name,function_description,module_date)VALUES('$nameClr','$ModuleClr','$DescriptionClr','$DateClr')";
		if (mysqli_query($conn, $sql)) {
			return True;
		} else {
			return False;
		}
	}
	?>

	<div id="top" class="bg-image d-flex" style="
	background-image: url('./image/background.png');
	height:100vh;">
		<section class="container mt-5">
			<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
				<fieldset>
					<div class="form-group">
						<label for="sID">User ID:</label>
						<input type="text" class="form-control" id="sID" name="FunctionUserID">
					</div>

					<div class="form-group">
						<label for="fname">Function Name:</label>
						<input type="text" class="form-control" id="fname" name="FunctionName" maxlength="50">
					</div>

					<div class="form-group">
						<label for="fname">Function Description:</label>
						<input type="text" class="form-control" id="fname" name="FunctionDescription" maxlength="50">
					</div>

					<div class="form-group">
						<label for="fname">Date:</label>
						<input type="text" class="form-control" id="fname" name="FunctionDate" maxlength="10">
					</div>

					<div class="register-button" id="input-3">
						<div class="circle-3"></div>
						<button type="submit">Add Staff</button>
					</div>
				</fieldset>
			</form>
		</section>
	</div>
</body>

</html>