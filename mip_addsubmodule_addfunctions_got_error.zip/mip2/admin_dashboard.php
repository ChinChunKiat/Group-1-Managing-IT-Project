<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="bootstrap, bootstrap4" />
    <meta name="author" content="QiChengDayo">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

</head>

<body style="
    background-image: url('./image/background.png');
    height:150vh;">
    <?php
    include "./include/header.php";
    ?>

    <!-- Start Product Section -->
    <div class="product-section">
        <div class="container">
            <div class="row">

                <!-- Start Column 1 -->
                <div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
                    <h2 class="mb-4 section-title">How is your Feeling Today?</h2>
                    <p class="mb-4">We designed and developed the following software: Accounting, Human Resources
                        Information System, Payroll, Terminal Operation System, Point of Sales and Farm Operation
                        System. </p>
                </div>
                <!-- End Column 1 -->

                <!-- Start Column 2 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="#">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail">
                        <h3 class="product-title text-white">View all Module, submodule, functions</h3>
                        <strong class="product-price text-white">View Modules</strong>
                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 2 -->

                <!-- Start Column 3 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="Admin_Register_User.php">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail" style="z-index: 2;">
                        <h3 class="product-title text-white">Register User</h3>
                        <strong class="product-price text-white">User Page</strong>
                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 3 -->

                <!-- Start Column 4 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="Admin_Announcement.php">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail">
                        <h3 class="product-title text-white">New Announcement</h3>
                        <strong class="product-price text-white">Announcement Page</strong>

                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 4 -->

            </div>
        </div>
    </div>
    <!-- End Product Section -->

    <!-- Add Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</body>

</html>