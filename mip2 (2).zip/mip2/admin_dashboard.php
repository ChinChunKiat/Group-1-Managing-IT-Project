<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="bootstrap, bootstrap4" />
    <meta name="author" content="QiChengDayo">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/style.css">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/templatemo-klassy-cafe.css">
    <link rel="stylesheet" href="css/header.css">
    <script>
        function toggleSideMenu() {
            var sideMenu = document.getElementById("sideMenu");
            sideMenu.style.width = sideMenu.style.width === "250px" ? "0" : "250px";
        }
    </script>

</head>

<body>
    <?php
    $pageTitle = "Pasti Nyala";
    $userIconPath = "./image/profile.png";
    ?>
    <header>
        <div class="header-container">

            <div class="logo">
                <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
            </div>
            <div class="user-icon" onclick="toggleSideMenu()">
                <img src="<?php echo $userIconPath; ?>" alt="User Icon">
            </div>
        </div>

        <!-- Inside the div with class="side-menu" -->
        <div class="side-menu" id="sideMenu">
            <div class="close-btn" onclick="toggleSideMenu()">&times;</div>

            <div class="user-info">
                <div class="user-icon" onclick="toggleSideMenu()">
                    <img src="<?php echo $userIconPath; ?>" alt="User Icon">
                </div>
                <div class="logout">
                    <a href="logout.php">Logout</a>
                </div>
            </div>

            <nav class="menu-navigation">
                <a href="manage_module.php">Modules</a>
                <a href="manage_module.php">Sub Modules</a>
                <a href="manage_module.php">Functions</a>
                <a href="#">View Users</a>
                <a href="#">View Requests</a>
            </nav>
        </div>
    </header>



    <!-- Start Product Section -->
    <div class="product-section">
        <div class="container">
            <div class="row">

                <!-- Start Column 1 -->
                <div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
                    <h2 class="mb-4 section-title">How is your Feeling Today?</h2>
                    <p class="mb-4">We designed and developed the following software: Accounting, Human Resources
                        Information System, Payroll, Terminal Operation System, Point of Sales and Farm Operation
                        System. </p>
                </div>
                <!-- End Column 1 -->

                <!-- Start Column 2 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="Admin_Add_Module.php">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail">
                        <h3 class="product-title">Make Change With Module</h3>
                        <strong class="product-price">Module Page</strong>

                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 2 -->

                <!-- Start Column 3 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="Admin_Register_User.php">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail">
                        <h3 class="product-title">Register User</h3>
                        <strong class="product-price">User Page</strong>

                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 3 -->

                <!-- Start Column 4 -->
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item" href="Admin_Announcement.php">
                        <img src="image/admin_login.png" class="img-fluid product-thumbnail">
                        <h3 class="product-title">New Announcement</h3>
                        <strong class="product-price">Announcement Page</strong>

                        <span class="icon-cross">
                            <img src="image/cross.svg" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column 4 -->

            </div>
        </div>
    </div>
    <!-- End Product Section -->

    <!-- Add Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</body>

</html>