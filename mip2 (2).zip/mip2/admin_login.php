<?php
include "include/include_database.php";

// Function to sanitize input data
function sanitize_input($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $User_ID = sanitize_input($_POST["User_ID"]);
    $Admin_Login_password = sanitize_input($_POST["password"]);

    // Fetch admin data from the database
    $sql = "SELECT * FROM login_table WHERE staff_id = '$User_ID' AND password = '$Admin_Login_password'";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // User exists, check password and type
            $Admin_stored_password = $row["password"];
            $user_type = $row["type"];

            if ($Admin_Login_password === $Admin_stored_password && $user_type === 'admin') {
                // Redirect to admin_dashboard.php
                session_start();

                header("Location: admin_dashboard.php");
                exit();
            }
        } else {
            // Authentication failed
            $error_message = "Invalid userID or password";
        }
    }

    // Close the connection only if it was successfully opened
    if ($conn->ping()) {
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="bootstrap, bootstrap4" />
    <meta name="author" content="QiChengDayo">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/style.css">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/templatemo-klassy-cafe.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg  navbar-dark " id="nav-bar">
        <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
        <!-- Toggle button for mobile navigation -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
    <div id="top" class="bg-image d-flex" style="
    background-image: url('./image/background.png');
    height:150vh;">
        <div class="container">
            <div class="row">



                <div class="container py-5 h-100">
                    <div class="row d-flex align-items-center h-100">
                        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                            <div class="card text-white" style="border-radius: 1rem;" id="user_form">
                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <div class="card-body p-5 text-center">
                                        <div class="mb-md5 mt-md4 pb-5">
                                            <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
                                            <p class="text-white-50 mb-5">Please enter your login ID and password!</p>

                                            <div class="form-outline form-white mb-4">
                                                <label class="form-label" for="User_ID">User ID:</label>
                                                <input type="Text" id="User_ID" class="form-control form-control-lg"
                                                    name="User_ID" />
                                            </div>

                                            <div class="form-outline form-white mb-4">
                                                <label class="form-label" for="password">Password:</label>
                                                <input type="password" id="password"
                                                    class="form-control form-control-lg" name="password" />
                                            </div>

                                            <button class="btn btn-outline-light btn-lg px-5"
                                                type="submit">Login</button>
                                        </div>
                                        <?php if (isset($error_message)): ?>
                                            <p class="Err">
                                                <?php echo $error_message; ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Add Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>