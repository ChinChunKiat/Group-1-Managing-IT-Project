<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="description" content="KPI Assignment System"/>
	<meta name="keywords" content="HTML5, tags"/>
	<meta name="author" content="Albert Lee Kai Xian"/>
	<link rel="stylesheet" type="text/css" href="style/style1.css">

	<title>Index</title>

</head>

<body>
	<?php
include "include/include_database.php";


		//echo mysqli_num_rows($result);
		if($_SERVER["REQUEST_METHOD"] == "POST"){
            //include "include/connection.php";
            //if(isset($_POST["SubUserID"]) && (!empty($_POST["SubUserID"]))){
                //$nameClr = $_POST["SubUserID"];
            //}

			if(isset($_POST["ModuleName"]) && (!empty($_POST["ModuleName"]))){
                $ModuleClr = $_POST["ModuleName"];
            }
			
            if(isset($_POST["SubModuleName"]) && (!empty($_POST["SubModuleName"]))){
                $SubModuleClr = $_POST["SubModuleName"];;
            }

            if(isset($_POST["SubDescription"]) && (!empty($_POST["SubDescription"]))){
                $DescriptionClr = $_POST["SubDescription"];
            }

			$CurrentDate = date("Y/m/d");

            // $sql = "SELECT * FROM module_table WHERE staff_id = '$nameClr'";
			// $result = mysqli_query($conn,$sql);
            // $num_result = mysqli_num_rows($result);
			// if($num_result >= 1){
				if(isset($ModuleClr, $SubModuleClr, $DescriptionClr,$CurrentDate)){
                    $insert_1 = insert_in_submodule_table($ModuleClr, $SubModuleClr, $DescriptionClr,$CurrentDate,$conn);
                        mysqli_close($conn);
                }
			// }
            // else{
            //     $idErr = "Staff ID already exist!";
            // }
		}

        function insert_in_submodule_table($ModuleClr, $SubModuleClr, $DescriptionClr,$CurrentDate,$conn){
			$sql="INSERT submodule_table(module_name,submodule_name,submodule_description,module_date)VALUES('$ModuleClr','$SubModuleClr','$DescriptionClr','$CurrentDate')";
			if(mysqli_query($conn,$sql)){
				return True;
			}
			else{
				return False;
			}
		}
	?>
	
    <header>
		<h1>Sub module</h1>
	</header>
	
	<section>
		<form method="post" action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			<fieldset>
                <p><label for="ModuleName">Module Name: </label>
				<select name="ModuleName" id="cars">
					<?php
						$sql = "SELECT module_name FROM module_table";
						$result = mysqli_query($conn,$sql);

						if ($result) {
							// Fetch each row as an associative array
							while ($row = mysqli_fetch_assoc($result)) {
								// Access the 'module_name' column value for each row
								$moduleName = $row['module_name'];
						
								// Do something with $moduleName (e.g., print it)
								//echo $moduleName . "<br>";
								echo '<option value="' ,$moduleName, '">',$moduleName, '</option>';
							}
						
							// Free the result set
							mysqli_free_result($result);
						}
					?>
				</select></p>

                <p><label for="fname">Sub-Module Name: </label>
				<input type="text" id="fname" name="SubModuleName"  maxlength="50"></span></input></p>

                <p><label for="fname">Sub-Module Description: </label>
				<input type="text" id="fname" name="SubDescription"  maxlength="50"></input></p>

                <!--Hidden date-->
				<input type="hidden" id="fname" name="CreateDate" value="$CurrentDate" maxlength="10"></input></p>

				<p><button type="submit" value="submit">Add Submodule</button></p>
			</fieldset>
		</form>
	</section>	
</body>
</html>