<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <title>MIP Assignment1</title>
</head>

<?php
$loginErr = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_login_id = $_POST["User_Login_ID"];
    $user_login_password = $_POST["User_Login_Password"];

    include "include/include_database.php";

    $user_login_id = mysqli_real_escape_string($conn, $user_login_id);
    $user_login_password = mysqli_real_escape_string($conn, $user_login_password);

    $sql = "SELECT*FROM login_table WHERE staff_id = '$user_login_id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if ($result->num_rows > 0) {

            $row = mysqli_fetch_assoc($result);
            // User exists, check password and type
            $stored_password = $row["password"];
            $user_type = $row["type"];

            if ($user_login_password === $stored_password && $user_type === 'user') {
                // Redirect to user_dashboard.php
                header("Location: user_dashboard.php");
                exit();
            }
        } else {
            $loginErr = "Invalid password or user not exist";
        }
    } else {
        // User does not exist
        $loginErr = "User not exist";
    }
    // Close connection
    mysqli_close($conn);
}

?>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg  navbar-dark " id="nav-bar">
        <a class="navbar-brand text-white" href="./index.php">Pasti Nyala</a>
        <!-- Toggle button for mobile navigation -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Navigation links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <!-- <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link text-white" href="">Main Module</a>
                </li>
                <li class="nav-item text-white">
                    <a class="nav-link text-white" href=".">Sub Module</a>
                </li>
                <li class="nav-item text-white">
                    <a class="nav-link text-white" href=".">Function</a>
                </li>
            </ul> -->
        </div>
    </nav>
    <section class="vh-100">
        <div class="bg-image d-flex" style="
            background-image: url('./image/background.png');
            height: 100vh;
          ">
            <div class="container py-5 h-100">
                <div class="row d-flex align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card text-white" style="border-radius: 1rem;" id="user_form">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="card-body p-5 text-center">
                                    <div class="mb-md5 mt-md4 pb-5">
                                        <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
                                        <p class="text-white-50 mb-5">Please enter your login ID and password!</p>

                                        <div class="form-outline form-white mb-4">
                                            <label class="form-label" for="typeEmailX">User ID:</label>
                                            <input type="Text" id="typeEmailX" class="form-control form-control-lg"
                                                name="User_Login_ID" />
                                        </div>

                                        <div class="form-outline form-white mb-4">
                                            <label class="form-label" for="typePasswordX">Password:</label>
                                            <input type="password" id="typePasswordX"
                                                class="form-control form-control-lg" name="User_Login_Password" />
                                        </div>

                                        <button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button>
                                    </div>
                                    <?php echo "<p class = 'Err'>" . $loginErr . "</p>" ?>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

</body>

</html>